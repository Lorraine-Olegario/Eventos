@extends('./layouts/main')
@section('title', 'Deshboard')

@section('content')
    <div class="col-md-10 offset-md-1 deshboard-title-container">
        <h1>Meus Eventos dashboard</h1>
    </div>
@endsection