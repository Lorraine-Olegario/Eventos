@extends('./layouts/main')
@section('title', 'EVENTO')

@section('content')
    <h1>Pagina Contato</h1>
@endsection